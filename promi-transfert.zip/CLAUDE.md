# CLAUDE.md — Promi

> Ce fichier est relu à chaque session. Il fait autorité sur tout le reste.
> Si une consigne de l'utilisateur contredit ce fichier, **demander avant d'agir**.

---

## 1. Ce qu'est Promi

Une application mobile française pour **tenir sa parole**. On y « plante » des
promesses — les **Promi** — qui deviennent des dalles colorées sur une **Toile**
personnelle. On tient sa parole par un **geste tracé au doigt**, pas par une case
à cocher.

Ce n'est **pas** une to-do list. Toute décision qui la rapproche d'un gestionnaire
de tâches est à rejeter, même si elle est fonctionnellement pratique.

**Public visé :** grand public, usage social et affectif. L'app doit provoquer une
émotion, pas de l'efficacité.

---

## 2. Vocabulaire — invariable

| Mot | Sens | Notes |
|---|---|---|
| **Promi** | une promesse, une dalle | invariable au pluriel : « trois Promi » |
| **dalle** | la forme colorée d'un Promi sur la Toile | synonyme de Promi |
| **Toile** | le canevas principal, Voronoï pondéré | **ne jamais modifier son code** |
| **Nuée** | un collectif de Promi (groupe, projet) | |
| **Brouillon** | un Promi non encore planté | |
| **Fil** | le flux d'activité | |
| **Aura** | l'écran de progression et d'analyse | anciennement « Karma » |
| **Studio** | le sélecteur de monde graphique | |
| **Le Cercle** | l'abonnement payant | |
| **Peaufiner** | le tiroir de réglages, en bas de chaque fiche | |
| **Index** | la liste complète des Promi | |
| **planter** | créer un Promi | |
| **tenir** | honorer sa parole | |

**Termes bannis** — ne jamais les employer, même en interne :
« Belle parole » comme bouton · « En replanter un » · « Dire un mot » comme gros
bouton · « tâche » · « to-do » · « objectif » · « échéance » comme libellé de champ.

---

## 3. Les couleurs — la règle des trois tons

Un écran de fiche porte **toujours trois couleurs distinctes** :

1. **La dalle** — sa couleur propre, issue du monde choisi au Studio
2. **Le fond** — l'état du Promi
3. **Les traits** — une troisième teinte, dérivée de la dalle

### Les couleurs d'état (fond)

```
#2BE88C   menthe       tenue
#F07A2E   orange       à tenir
#E4CEFD   lilas        Nuée (clair)
#8A5CF0   mauve        Nuée (soutenu)
#3A54FF   bleu         création, Promi
neutre    periwinkle   en cours
#F4EEE1   crème        surface claire
#16171B   encre        surface sombre
```

### Les corps de fiche (plus clairs que le haut)

```
                clair       sombre
à tenir         #F6DCC4     #2E1C13
tenue           #AEE5CE     #0C2B1F
Nuée            #F3E9FE     #1B1426
```

### Les traits

Ils prennent la teinte de la dalle **décalée de 150° en teinte**, saturation
remontée à 55 % minimum. Cela garde la famille chromatique du monde choisi tout
en évitant le ton sur ton.

> **⚠ Point ouvert** — l'utilisateur juge ce décalage parfois hors palette.
> Une décision est attendue : soit conserver le décalage, soit piocher une
> couleur réelle de la palette du monde actif. **Ne pas trancher seul.**

**Une Nuée** prend la teinte de **sa dernière dalle plantée** — ses traits
changent à chaque nouveau Promi.

### Interdits absolus sur les couleurs

- **Jamais de trait neutre ou gris.** Un filet sans couleur est un défaut.
- **Jamais de ton sur ton.** Vérifier l'écart de luminosité, seuil 42.
- `-webkit-text-fill-color` doit **toujours** valoir la même chose que `color` —
  sinon le texte se peint dans la couleur du fond.
- Sur un aplat d'état, l'encre s'inverse : `#06231A` sur menthe, `#FFFFFF` sur
  orange.

---

## 4. Les dalles — règles absolues

1. **Toujours la vraie dalle**, rendue par `Toile.dalleTrame(canvas, id, 1)`.
   Jamais un polygone, jamais une photo, jamais une approximation.
2. **L'échelle est toujours 1.** Les valeurs 6 ou plus cassent les mondes
   mosaïque, braille, pixel et gravure — ils retombent sur un rendu polygonal.
3. **La dalle est au premier plan.** `opacity: 1`, `filter: none`,
   `mix-blend-mode: normal`, `z-index` supérieur au voile de couleur.
   Le voile est le `background` du bloc, jamais un calque par-dessus.
4. **Aucun filtre, aucun voile, aucun masque** ne passe devant une dalle.
5. **Peindre après insertion.** Les canevas ne sont mesurables qu'une fois
   disposés : relancer `peintMinis()` à 0, 60, 200 et 600 ms.
6. **Jamais de dalle en fond animé** sur un écran qui montre des dalles de
   référence.

**Les neuf mondes :**
gratuits — Encre · Mosaïque · Touffe · Braille · Pixel
Cercle — Terrazzo · Gravure · Sillons · Éclats

---

## 5. Les composants communs

Ces éléments sont **identiques sur tous les écrans**. Ne jamais en créer une
variante locale.

| Composant | Règle |
|---|---|
| **Le geste** | 118 px de haut, deux points, un trait. Toujours **entier**, jamais rogné ni superposé. Le trait part **du centre du rond gauche**, pas du doigt. Courbes quadratiques, jamais de segments droits. |
| **Peaufiner** | 62 px, en bas de chaque fiche. Même typographie, même filet, même place. Porte l'icône de partage à droite. |
| **✕ Fermer** | En haut à droite, `top: 50px`, avec le texte `FERMER`. |
| **Le mot-marque** | « Promi » en Fraunces, haut à gauche, 20 px. 15 px dans les images partagées. |
| **« Moi »** | Toujours **premier** de la liste des destinataires, avec son avatar dégradé. Dans une Nuée : « tout le monde » passe devant, « Moi » ensuite. |
| **Les boutons ronds** | Partager, commenter, joindre : **icône seule**, jamais de texte à côté. |

---

## 6. La typographie

```
Bricolage Grotesque   titres, libellés de section   700/800
Apfel                 champs, interface
Fraunces              signature « Promi »
```

**Tailles minimales :** rien en dessous de 12 px. Aucune opacité sous 72 % sur du
texte lisible.

---

## 7. Méthode de patch — obligatoire

### Avant toute modification

1. Lire le code existant **avant** de le modifier. Ne jamais deviner.
2. Vérifier qu'une règle CSS s'applique réellement : le fichier contient
   **2 400 règles dont 54 % sont mortes**. Une déclaration peut être écrasée
   par une règle postérieure sans que ce soit visible.

### La méthode

```python
# Toujours ce motif, jamais un replace aveugle
assert S.count(old) == 1, "motif absent ou multiple"
S = S.replace(old, new)
```

### Après toute modification

```bash
# 1 · vérifier la syntaxe JS
python3 -c "import re,io; S=io.open('app.html',encoding='utf-8').read();
io.open('check.js','w',encoding='utf-8').write(''.join(m.group(1)
for m in re.finditer(r'<script[^>]*>(.*?)</script>',S,re.S)))"
node --check check.js

# 2 · les sept batteries
python3 redteam_ecrans.py     # 142 contrôles — la principale
python3 redteam.py            # 15
python3 redteam2.py           # 10
python3 redteam3.py           # 18
python3 redteam_demande.py    # 19
python3 redteam_toile.py      # 16
python3 redteam_geste.py      # 13
```

**Aucune livraison si une batterie régresse.**

### Vérification visuelle Playwright

```python
viewport = {'width': 390, 'height': 844}
device_scale_factor = 2
pg.wait_for_timeout(6800)   # minimum après navigation
pg.evaluate("()=>{var o=document.getElementById('promiOnb');
  if(o){o.classList.add('gone');o.style.display='none';}}")   # passer l'onboarding
```

Pour vérifier une couleur peinte dans un canevas, **échantillonner les pixels** —
c'est la seule méthode fiable :

```javascript
const d = g.getImageData(0,0,c.width,c.height).data;
for(let i=3; i<d.length; i+=300) if(d[i]>10) n++;
```

---

## 8. Les pièges connus — les relire avant de déboguer

| Symptôme | Cause réelle |
|---|---|
| Une règle CSS « ne marche pas » | Une règle postérieure l'écrase. Chercher **toutes** les occurrences du sélecteur. |
| Le texte est invisible | `-webkit-text-fill-color` diffère de `color`. |
| La dalle est délavée | `opacity` ou `filter` posé par une règle groupée avec `.tracant`. |
| La dalle est polygonale | `dalleTrame` appelé avec une échelle > 1. |
| Un canevas est vide | `peintMinis` appelé avant que le canevas soit disposé. |
| L'app rame, les captures échouent | Un `MutationObserver` qui s'auto-déclenche : la fonction observée modifie une classe, ce qui réveille l'observateur. **Toujours comparer l'état avant d'agir.** |
| Un bloc ne bouge pas | Le CSS ne déplace pas les blocs. Réordonner le DOM en JavaScript. |
| `cur` est nul | Sur une fiche de Nuée, c'est `curNuee` qui porte le groupe. |
| Un sélecteur ne correspond à rien | `personSheet` vit sous `.frame`, pas sous `.device`. |
| Le scroll est bloqué | Un `position: sticky` avec `bottom: 0` qui change de position en s'ouvrant. |

**Noms de variables à connaître :**
`NUE` (table des noms de Nuée) · `curNuee` (clé de la Nuée ouverte) ·
`promises` (tous les Promi) · `Toile.dalleTrame` · `peintMinis` ·
`_teinteDalle` · `_fichePose` · `_ficheDalle`

---

## 8 bis. LE CONTRAT VISUEL — la règle qui prime sur toutes les autres

Le design de Promi est le fruit de **plusieurs centaines d'itérations**. Chaque
taille, chaque couleur, chaque marge a été arbitrée. **Rien n'est arbitraire.**

### Ne jamais réécrire — seulement patcher

**Interdit absolu :**
- réécrire un écran « proprement »
- refactoriser le CSS ou le JS
- remplacer un composant par une version « équivalente »
- normaliser des valeurs qui paraissent incohérentes

Si une valeur paraît étrange (un `-66px`, un `1.6px`, un `.42`), **elle est
étrange pour une raison**. Ne pas l'arrondir, ne pas la « corriger ».

### Le contrôle obligatoire

Avant et après chaque lot :

```bash
python3 releve-design.py
```

Le script relève **148 propriétés sur 26 éléments dans 6 configurations** et
compare à `design-reference.json`.

```
✅  AUCUN ÉCART. Le design est intact.        → on peut livrer
❌  N ÉCARTS avec la référence                 → régression, corriger
❌  N COULEURS FAUTIVES                        → un trait neutre est apparu
```

**Un écart non demandé par le lot est une régression.** Le corriger avant de
livrer, ou expliquer précisément pourquoi il était inévitable.

Après un lot **validé par l'utilisateur** :

```bash
python3 releve-design.py --figer
```

### Ce que le script ne voit pas

Il ne vérifie ni le placement relatif, ni les superpositions, ni le rendu réel
des dalles. **Les captures avant/après restent obligatoires.**

---

## 9. Ce qu'il ne faut jamais faire

- **Toucher au code de la Toile.** Elle est validée et fragile. Aucune
  modification sans demande explicite.
- **Nettoyer le CSS.** Cinq tentatives, cinq échecs documentés. L'ordre des
  769 règles du dernier bloc est significatif ; toute suppression casse le rendu.
  Voir `ETAT-DES-LIEUX.md § dette technique`.
- **Inventer pendant un lot de correction.** Un lot corrige ce qui est décrit,
  rien d'autre. Les éléments d'identité arrivent par moodboard.
- **Livrer sans avoir vérifié.** Si le résultat n'est pas conforme, le dire.
  Une livraison fausse coûte plus qu'un tour perdu.
- **Enchaîner plusieurs chantiers dans un lot.** Un lot = un écran = un
  avant/après.

---

## 10. Le ton des réponses

L'utilisateur travaille en français, écrit vite, avec des fautes de frappe, et
dicte parfois à la voix. Il a une tolérance faible pour les régressions et pour
les affirmations non vérifiées.

- Annoncer ce qui a été **mesuré**, avec les chiffres.
- Dire clairement ce qui n'a **pas** été fait.
- Ne jamais prétendre qu'une chose est corrigée sans l'avoir vue.
